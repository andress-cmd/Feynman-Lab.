export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método no permitido." });
  }

  try {
    const { task, question, instruction, source, extra } = req.body || {};
    if (!source) return res.status(400).json({ error: "No se recibió contenido del documento." });

    const tasks = {
      explicacion_simple: "Explica el concepto solicitado con lenguaje claro. Busca la respuesta SOLO dentro del documento. No copies el párrafo: reformúlalo. Mantén los términos importantes del autor. Incluye: qué significa, explicación paso a paso, ejemplo cotidiano, analogía sencilla y qué recordar para un examen.",
      feynman: "Aplica la técnica Feynman al documento. Identifica la idea central, explíquela como a un estudiante que empieza, detecta posibles vacíos, usa una analogía cotidiana y termina con una explicación corta que el estudiante pueda repetir con sus propias palabras.",
      vida_cotidiana: "Relaciona los conceptos del documento con situaciones cotidianas reales. Conserva el significado del material y distingue claramente ejemplos de cualquier información que no aparezca en el documento.",
      quiz: "Crea preguntas de estudio basadas exclusivamente en el documento. Incluye las respuestas correctas y una explicación breve. No inventes datos que no estén respaldados por el documento.",
      exposicion: "Convierte el documento en una guía para una exposición clara. Organiza objetivo, introducción, ideas principales, explicación sencilla, ejemplo cotidiano, conclusión y preguntas que podrían hacerle al estudiante."
    };

    const taskInstruction = tasks[task] || "Ayuda al estudiante a comprender el documento.";
    const prompt = `
NECESIDAD DEL ESTUDIANTE:
${instruction || "Comprender y estudiar el documento."}

SOLICITUD:
${question || "Explica el contenido principal."}

TAREA:
${taskInstruction}

${extra || ""}

REGLAS:
- Usa el documento como fuente principal.
- No inventes información.
- Si algo no está en el documento, dilo.
- Responde en español.
- No copies grandes fragmentos literalmente.
- Prioriza claridad y comprensión.
- Conserva la terminología académica importante del material.

DOCUMENTO:
${source}
`;

    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
        input: prompt,
        store: false
      })
    });

    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      return res.status(apiResponse.status).json({
        error: data?.error?.message || "Error de la API de IA."
      });
    }

    let text = data.output_text;
    if (!text && Array.isArray(data.output)) {
      text = data.output.flatMap(item =>
        (item.content || []).map(c => c.text || c.output_text || "")
      ).filter(Boolean).join("\n");
    }
    if (!text) text = "La IA no devolvió una respuesta de texto.";
    return res.status(200).json({ text });
  } catch (error) {
    return res.status(500).json({ error: "Error interno del servidor." });
  }
}
